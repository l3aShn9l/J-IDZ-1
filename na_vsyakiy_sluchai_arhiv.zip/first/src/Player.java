class Player {
    protected String _name;
    public Player(String name) {
        _name = name;
    }
    public final String getName() {
        return _name;
    }
}